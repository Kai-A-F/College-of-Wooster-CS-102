import media

#### Create your super neato functions here! ####














# Open your image(s)

# Create a canvas

# Run your functions and place the resulting image on your canvas

# Output the canvas to an image file with media.writePictureTo()

# Clean up media content
media.quit()